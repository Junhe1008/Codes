library(FinTS)
library(rugarch)
library(dynlm)
library(tseries)
library(stats)
dataset = Cars
attach(Cars)
rc = ts(Cars$`Carprice`)
arcar = ar.ols(dataset, 
       order.max = 4, 
       demean = F, 
       intercept = T)

residuals(ar(rc,aid = FALSE,order.max = 4,method = "ols"))

arcar = ar(Carprice, FALSE, 4)
arcar
resid(arcar)
ar(Carprice, aid = FALSE, order.max = 4, method = "ols")$resid
arcar$resid
res = arcar$resid
View(res)
mean(res)